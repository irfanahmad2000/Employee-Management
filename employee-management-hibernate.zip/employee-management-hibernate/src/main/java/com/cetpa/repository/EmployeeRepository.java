package com.cetpa.repository;

import java.util.*;

import org.hibernate.*;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cetpa.model.Employee;

@Repository
public class EmployeeRepository 
{
	private Session	session;
	private Transaction transaction;
	
	@Autowired
	public EmployeeRepository(SessionFactory factory)	
	{
		session=factory.openSession();
		transaction=session.getTransaction();
	}
	public void saveRecord(Employee employee) 
	{
		transaction.begin();
		session.save(employee);
		transaction.commit();
	}
	public List<Employee> getEmployeeList() 
	{
		Query<Employee> query=session.createQuery("from Employee",Employee.class);
		List<Employee> employeeList=query.list();
		return employeeList;
	}
	public Employee getRecord(int eid) 
	{
		Employee employee=session.get(Employee.class,eid);
		return employee;
	}
	public void deleteEmployee(Employee employee) 
	{
		transaction.begin();
		session.delete(employee);
		transaction.commit();
	}
}
