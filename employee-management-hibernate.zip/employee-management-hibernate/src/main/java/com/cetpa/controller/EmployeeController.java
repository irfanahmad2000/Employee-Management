package com.cetpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cetpa.model.Employee;
import com.cetpa.repository.EmployeeRepository;
import com.cetpa.service.EmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping("/")
	public String getHomeView()
	{
		return "home.jsp";
	}
	@RequestMapping("add-employee")
	public String getInsertView()
	{
		return "insert.jsp";
	}
	@RequestMapping("/save-record")
	public String saveEmployeeRecord(Employee employee)
	{
		employeeService.insertRecord(employee);
		return "save.jsp";
	}
	@RequestMapping("employee-list")
	public String getEmployeeListView(Model model)
	{
		List<Employee> employeeList=employeeService.getList();
		model.addAttribute("elist",employeeList);
		return "list.jsp";
	}
	@RequestMapping("search-employee")
	public String getSearchView()
	{
		return "search.jsp";
	}
	@RequestMapping("search-record")
	public String searchEmployeeRecord(int eid,Model model)
	{
		Employee employee=employeeService.getEmployee(eid);
		if(employee==null)
		{
			model.addAttribute("msg","Employee with id "+eid+" not found");
			return "search.jsp";
		}
		model.addAttribute("emp", employee);
		return "show.jsp";
	}
	@RequestMapping("delete-employee")
	public String getDeleteView()
	{
		return "delete.jsp";
	}
	@RequestMapping("delete-record")
	public String deleteEmployeeRecord(int eid,Model model)
	{
		Employee employee=employeeService.getEmployee(eid);
		if(employee==null)
		{
			model.addAttribute("msg","Employee with id "+eid+" does not exist");
			return "delete.jsp";
		}
		employeeService.deleteRecord(employee);
		model.addAttribute("msg","Employee with id "+eid+" has been deleted");
		return "delete.jsp";
	}
	@RequestMapping("edit-employee")
	public String getEditView()
	{
		return "edit.jsp";
	}
	@RequestMapping("get-record")
	public String getEmployeeRecord(int eid,Model model)
	{
		Employee employee=employeeService.getEmployee(eid);
		if(employee==null)
		{
			model.addAttribute("msg","Employee with id "+eid+" not found");
			return "edit.jsp";
		}
		model.addAttribute("emp", employee);
		return "update.jsp";
	}
}
