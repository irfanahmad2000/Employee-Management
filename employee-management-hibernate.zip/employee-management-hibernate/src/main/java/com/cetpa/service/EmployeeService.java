package com.cetpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cetpa.model.Employee;
import com.cetpa.repository.EmployeeRepository;

@Service
public class EmployeeService 
{
	public EmployeeService()
	{
		System.out.println("Service created...");
	}
	@Autowired
	private EmployeeRepository employeeRepository;

	public void insertRecord(Employee employee) 
	{
		employeeRepository.saveRecord(employee);
	}

	public List<Employee> getList() 
	{
		return employeeRepository.getEmployeeList();
	}
	public Employee getEmployee(int eid) 
	{
		return employeeRepository.getRecord(eid);
	}
	public void deleteRecord(Employee employee) 
	{
		employeeRepository.deleteEmployee(employee);
	}
}
